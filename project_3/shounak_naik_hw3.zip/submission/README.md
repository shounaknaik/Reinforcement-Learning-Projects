The saved model is `dqn_model.pth`
